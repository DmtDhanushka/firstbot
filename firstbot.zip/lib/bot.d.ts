import { ActivityHandler, TurnContext } from 'botbuilder';
export declare class EchoBot extends ActivityHandler {
    constructor();
    sendWelcomeMessage(context: TurnContext): Promise<void>;
    sendSuggestedActions(turnContext: any): Promise<void>;
}
