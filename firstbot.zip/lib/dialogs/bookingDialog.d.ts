import { ComponentDialog, DialogTurnResult, WaterfallStepContext } from 'botbuilder-dialogs';
import { BookingDetails } from './bookingDetails';
export declare class BookingDialog extends ComponentDialog {
    constructor();
    ageStep(stepContext: WaterfallStepContext<BookingDetails>): Promise<DialogTurnResult>;
    nameStep(stepContext: WaterfallStepContext<BookingDetails>): Promise<DialogTurnResult>;
    addressStep(stepContext: WaterfallStepContext<BookingDetails>): Promise<DialogTurnResult>;
    confirmStep(stepContext: WaterfallStepContext<BookingDetails>): Promise<DialogTurnResult>;
    summaryStep(stepContext: any): Promise<any>;
}
